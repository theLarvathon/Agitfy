<?php

use Illuminate\Support\Facades\Route;

// These names are referenced directly inside the Blade views via route().
// Wire them up to real controllers when the backend/data layer is ready.

Route::get('/', fn () => view('home'))->name('home');

Route::get('/cari', fn () => view('search'))->name('search');

Route::get('/mapel/{subject}', fn (string $subject) => view('subjects.show'))
    ->name('subjects.show');

Route::get('/mapel/{subject}/{topic}', fn (string $subject, string $topic) => view('topics.show'))
    ->name('topics.show');
