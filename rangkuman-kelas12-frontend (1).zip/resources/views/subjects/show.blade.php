@extends('layouts.app')

@section('title', $subject['name'] ?? 'Mata Pelajaran')

@section('content')

    @php
        // Would normally be injected by SubjectController@show
        $subject ??= ['code' => 'MTK', 'name' => 'Matematika', 'category' => 'sains'];
        $topics ??= [
            ['number' => 'Bab 1', 'title' => 'Barisan dan Deret',            'read' => 6,  'done' => true],
            ['number' => 'Bab 2', 'title' => 'Fungsi Komposisi dan Invers',  'read' => 8,  'done' => true],
            ['number' => 'Bab 3', 'title' => 'Limit Fungsi',                 'read' => 7,  'done' => false],
            ['number' => 'Bab 4', 'title' => 'Turunan Fungsi',               'read' => 10, 'done' => false],
            ['number' => 'Bab 5', 'title' => 'Integral',                    'read' => 9,  'done' => false],
        ];
    @endphp

    <div class="mx-auto max-w-3xl px-4 py-8 sm:px-6 sm:py-12">

        <x-breadcrumb :items="[
            ['label' => 'Beranda', 'href' => route('home')],
            ['label' => $subject['name']],
        ]" />

        <div class="mb-6 flex items-center gap-3">
            <span class="tab-badge bg-primary-600 text-lg text-white">{{ $subject['code'] }}</span>
            <div>
                <h1 class="font-display text-xl font-bold text-slate-900 dark:text-ink-100 sm:text-2xl">
                    {{ $subject['name'] }}
                </h1>
                <p class="text-xs text-slate-500 dark:text-ink-400">{{ count($topics) }} bab tersedia</p>
            </div>
        </div>

        <div class="space-y-2">
            @foreach ($topics as $t)
                <x-topic-item
                    :number="$t['number']"
                    :title="$t['title']"
                    :readMinutes="$t['read']"
                    :done="$t['done']"
                    :href="route('topics.show', [$subject['code'], \Illuminate\Support\Str::slug($t['title'])]) ?? '#'"
                />
            @endforeach
        </div>
    </div>

@endsection
