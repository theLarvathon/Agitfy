@extends('layouts.app')

@section('title', $topic['title'] ?? 'Rangkuman')

@section('content')

    @php
        // Would normally come from TopicController@show
        $subject ??= ['code' => 'MTK', 'name' => 'Matematika'];
        $topic ??= ['number' => 'Bab 4', 'title' => 'Turunan Fungsi', 'read' => 10];
        $toc ??= ['Konsep Dasar Turunan', 'Aturan Turunan', 'Turunan Fungsi Trigonometri', 'Aplikasi Turunan'];
    @endphp

    <div class="mx-auto max-w-6xl px-4 py-8 sm:px-6 sm:py-12">

        <x-breadcrumb :items="[
            ['label' => 'Beranda', 'href' => route('home')],
            ['label' => $subject['name'], 'href' => route('subjects.show', $subject['code'])],
            ['label' => $topic['number']],
        ]" />

        <div class="lg:grid lg:grid-cols-[1fr_240px] lg:items-start lg:gap-10">

            {{-- ============ MAIN CONTENT ============ --}}
            <article class="max-w-2xl">
                <div class="mb-6 flex items-center gap-3">
                    <span class="tab-badge bg-accent-500 font-mono text-white">{{ $topic['number'] }}</span>
                    <span class="font-mono text-xs text-slate-400 dark:text-ink-400">{{ $topic['read'] }} menit baca</span>
                </div>

                <h1 class="font-display text-2xl font-bold text-slate-900 dark:text-ink-100 sm:text-3xl">
                    {{ $topic['title'] }}
                </h1>

                <div class="prose-summary mt-6 space-y-5 text-sm leading-relaxed text-slate-700 dark:text-ink-100 sm:text-base">

                    <h2 id="konsep-dasar-turunan" class="font-display text-lg font-semibold text-slate-800 dark:text-ink-100">
                        1. Konsep Dasar Turunan
                    </h2>
                    <p>
                        Turunan sebuah fungsi menggambarkan laju perubahan nilai fungsi tersebut terhadap
                        perubahan variabel bebasnya. Secara geometris, turunan di suatu titik sama dengan
                        gradien garis singgung kurva di titik itu.
                    </p>

                    <x-callout type="note" label="Definisi">
                        f'(x) = lim<sub>h→0</sub> [f(x + h) − f(x)] / h
                    </x-callout>

                    <h2 id="aturan-turunan" class="font-display text-lg font-semibold text-slate-800 dark:text-ink-100">
                        2. Aturan Turunan
                    </h2>
                    <p>
                        Beberapa aturan dasar mempercepat perhitungan tanpa harus kembali ke definisi limit:
                        aturan pangkat, aturan hasil kali, aturan hasil bagi, dan aturan rantai.
                    </p>

                    <x-callout type="point">
                        Aturan rantai paling sering muncul di soal ujian — kenali pola fungsi komposisi
                        sebelum menurunkannya.
                    </x-callout>

                    <h2 id="turunan-fungsi-trigonometri" class="font-display text-lg font-semibold text-slate-800 dark:text-ink-100">
                        3. Turunan Fungsi Trigonometri
                    </h2>
                    <p>
                        Turunan sin x adalah cos x, dan turunan cos x adalah −sin x. Pola tanda ini penting
                        dihafal karena jadi dasar turunan fungsi trigonometri lain.
                    </p>

                    <h2 id="aplikasi-turunan" class="font-display text-lg font-semibold text-slate-800 dark:text-ink-100">
                        4. Aplikasi Turunan
                    </h2>
                    <p>
                        Turunan dipakai untuk menentukan nilai maksimum-minimum, kecepatan sesaat, dan
                        kemiringan garis singgung — tiga tipe soal yang paling sering keluar di ujian.
                    </p>
                </div>

                <div class="mt-10 flex items-center justify-between border-t border-slate-200 pt-4 dark:border-ink-700">
                    <a href="{{ route('subjects.show', $subject['code']) }}"
                       class="text-sm font-medium text-primary-600 hover:underline dark:text-primary-300">
                        ← Kembali ke daftar bab
                    </a>
                    <button type="button"
                            class="rounded-lg bg-accent-500 px-4 py-2 text-sm font-semibold text-white transition hover:bg-accent-600">
                        Tandai sudah dibaca
                    </button>
                </div>
            </article>

            {{-- ============ TOC — sticky on desktop, hidden on mobile ============ --}}
            <aside class="hidden lg:block">
                <div class="surface sticky top-20 rounded-xl p-4">
                    <p class="mb-3 font-mono text-[11px] font-bold uppercase tracking-wide text-slate-400 dark:text-ink-400">
                        Daftar Isi
                    </p>
                    <ul class="space-y-2 text-sm">
                        @foreach ($toc as $i => $section)
                            <li>
                                <a href="#{{ \Illuminate\Support\Str::slug($section) }}"
                                   class="text-slate-500 hover:text-primary-600 dark:text-ink-400 dark:hover:text-primary-300">
                                    {{ $i + 1 }}. {{ $section }}
                                </a>
                            </li>
                        @endforeach
                    </ul>
                </div>
            </aside>
        </div>
    </div>

@endsection
