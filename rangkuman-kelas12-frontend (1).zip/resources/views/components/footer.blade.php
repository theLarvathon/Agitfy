<footer class="border-t border-slate-200 py-6 text-center text-xs text-slate-500
               dark:border-ink-700 dark:text-ink-400">
    <p>Dibuat untuk membantu belajar — rangkuman ini bukan pengganti buku paket.</p>
</footer>
